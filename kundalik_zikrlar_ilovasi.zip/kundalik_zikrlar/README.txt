KUNDALIK ZIKRLAR — mini ilova

Ishlatish:
1. index.html faylini Android telefoningizga yuboring.
2. Chrome brauzerida oching.
3. Xohlasangiz Chrome menyusidan “Add to Home screen” / “Bosh ekranga qo‘shish” ni tanlang.

Ilova internet talab qilmaydi. Hisoblagichlar shu brauzer/qurilmada avtomatik saqlanadi.
Har bir zikr 100 martagacha sanaladi. “− 1” xatoni tuzatadi, ↺ esa shu zikrni qayta boshlaydi.
